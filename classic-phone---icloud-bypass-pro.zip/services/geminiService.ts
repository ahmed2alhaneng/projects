
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeDeviceIssue(model: string, version: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Provide a professional technical summary for bypassing iCloud on an ${model} running iOS ${version}. Mention specific exploits like checkm8 or ramdisk methods if applicable. Keep it brief and professional for a technician. Answer in Arabic.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "تعذر الحصول على تحليل فني حالياً. يرجى المحاولة لاحقاً.";
  }
}
